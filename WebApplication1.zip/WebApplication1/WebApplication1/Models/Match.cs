﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class Team
    {
        public string teamKey { get; set; }
        public string teamName { get; set; }
        public string code { get; set; }
    }
    public class Match
    {
        public string matchDate { get; set; }
        public string team1Code { get; set; }
        public string team2Code { get; set; }
        public int score1 { get; set; }
        public int score2 { get; set; }
    }

    public class Standing
    {
        public int teamRank { get; set; }
        public string teamName { get; set; }
        public int wins { get; set; }
        public int draws { get; set; }
        public int losses { get; set; }
        public int goals_for { get; set; }
        public int goals_against { get; set; }
        public int goals_difference { get; set; }
        public int points { get; set; }
    }
}
