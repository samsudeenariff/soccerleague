﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class Team
    {
        public string teamKey { get; set; }
        public string teamName { get; set; }
        public string code { get; set; }
    }
    public class Match
    {
        public string matchDate { get; set; }
        public string team1Code { get; set; }
        public string team2Code { get; set; }
        public int score1 { get; set; }
        public int score2 { get; set; }
    }
}
