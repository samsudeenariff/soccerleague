﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        public IConfiguration Configuration { get; }
        public HomeController(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IActionResult Index()
        {
            var standingsList = new List<Standing>();

            string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string sql = "Select * From Standings";
                SqlCommand command = new SqlCommand(sql, connection);

                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        var teamStanding = new Standing();
                        teamStanding.teamRank = Convert.ToInt32(dataReader["teamRank"]);
                        teamStanding.teamName = Convert.ToString(dataReader["teamName"]);
                        teamStanding.wins = Convert.ToInt32(dataReader["wins"]);
                        teamStanding.draws = Convert.ToInt32(dataReader["draws"]);
                        teamStanding.losses = Convert.ToInt32(dataReader["losses"]);
                        teamStanding.goals_for = Convert.ToInt32(dataReader["goals_for"]);
                        teamStanding.goals_against = Convert.ToInt32(dataReader["goals_against"]);
                        teamStanding.goals_difference = Convert.ToInt32(dataReader["goals_difference"]);
                        teamStanding.points = Convert.ToInt32(dataReader["points"]);

                        standingsList.Add(teamStanding);
                    }
                }

                connection.Close();
            }
            return View(standingsList);
        }
    }
}