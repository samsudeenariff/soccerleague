﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        public IConfiguration Configuration { get; }
        public HomeController(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        public IActionResult Index()
        {
            return View();
        }       
        public IActionResult Standings()
        {
            //  dataReader = new DataReader();
            var standingsList = new List<Match>();

            string connectionString = Configuration["ConnectionStrings:DefaultConnection"];
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                //SqlDataReader
                connection.Open();

                string sql = "Select * From Match";
                SqlCommand command = new SqlCommand(sql, connection);

                using (SqlDataReader dataReader = command.ExecuteReader())
                {
                    while (dataReader.Read())
                    {
                        var match = new Match();
                        match.matchDate = Convert.ToString(dataReader["matchDate"]);
                        match.team1Code = Convert.ToString(dataReader["team1Code"]);
                        match.team2Code = Convert.ToString(dataReader["team2Code"]);
                        match.score1 = Convert.ToInt32(dataReader["score1"]);
                        match.score2 = Convert.ToInt32(dataReader["score2"]);

                        standingsList.Add(match);
                    }
                }

                connection.Close();
            }
            return View(standingsList);
        }
    }
}