﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;
using WebApplication1.Models;

namespace WebApplication1
{
    public class DataReader
    {
        public DataReader()
        {
            using (StreamReader file = File.OpenText(@"data.json"))
            {
                using (JsonTextReader reader = new JsonTextReader(file))
                {
                    JObject data = (JObject)JToken.ReadFrom(reader);
                    var matches = data.Last.Children<JToken>().GetEnumerator();
                }
            }
        }
    }
}
